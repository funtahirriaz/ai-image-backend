from fastapi import FastAPI, HTTPException
import requests

app = FastAPI()

# Hugging Face Stable Diffusion API Endpoint
HF_API_URL = "https://api-inference.huggingface.co/models/stabilityai/stable-diffusion-2"
HF_HEADERS = {"Authorization": "Bearer YOUR_HUGGINGFACE_API_KEY"}

@app.get("/generate")
async def generate_image(prompt: str):
    data = {"inputs": prompt}
    response = requests.post(HF_API_URL, headers=HF_HEADERS, json=data)
    
    if response.status_code == 200:
        return {"image_url": response.json()}
    else:
        raise HTTPException(status_code=500, detail="Image generation failed")

@app.get("/")
async def home():
    return {"message": "AI Image Generator API is running"}
