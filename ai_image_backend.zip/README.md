# AI Image Generator Backend

This is a FastAPI-based backend for an AI Image Generator using Hugging Face's Stable Diffusion.

## Setup
1. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
2. Run the API:
   ```bash
   uvicorn main:app --host 0.0.0.0 --port 8000
   ```

## Usage
Send a GET request to `/generate?prompt=your_text_here` to generate an image.
